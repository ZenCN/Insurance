
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, and Azure
-- --------------------------------------------------
-- Date Created: 05/30/2016 10:04:36
-- Generated from EDMX file: I:\insurance\insurance\model\insurance.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [insurance];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------


-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[cases]', 'U') IS NOT NULL
    DROP TABLE [dbo].[cases];
GO
IF OBJECT_ID(N'[dbo].[field_range]', 'U') IS NOT NULL
    DROP TABLE [dbo].[field_range];
GO
IF OBJECT_ID(N'[dbo].[investigation]', 'U') IS NOT NULL
    DROP TABLE [dbo].[investigation];
GO
IF OBJECT_ID(N'[dbo].[lgn]', 'U') IS NOT NULL
    DROP TABLE [dbo].[lgn];
GO
IF OBJECT_ID(N'[InsuranceModelStoreContainer].[modify_color]', 'U') IS NOT NULL
    DROP TABLE [InsuranceModelStoreContainer].[modify_color];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'field_range'
CREATE TABLE [dbo].[field_range] (
    [fid] int IDENTITY(1,1) NOT NULL,
    [field_name] nvarchar(50)  NULL,
    [field_value] nvarchar(50)  NULL
);
GO

-- Creating table 'investigation'
CREATE TABLE [dbo].[investigation] (
    [id] int IDENTITY(1,1) NOT NULL,
    [cid] nvarchar(50)  NOT NULL,
    [investigation_cause] nvarchar(50)  NULL,
    [investigation_area] nvarchar(50)  NULL,
    [contact] nvarchar(50)  NULL,
    [contact_phone] nvarchar(50)  NULL,
    [survey_points] nvarchar(100)  NULL,
    [approval_result] nvarchar(50)  NULL,
    [approval_remark] nvarchar(100)  NULL
);
GO

-- Creating table 'lgn'
CREATE TABLE [dbo].[lgn] (
    [uid] int IDENTITY(1,1) NOT NULL,
    [user_name] nvarchar(50)  NOT NULL,
    [password] nvarchar(50)  NOT NULL,
    [authority_level] int  NOT NULL,
    [last_login_time] datetime  NULL
);
GO

-- Creating table 'modify_color'
CREATE TABLE [dbo].[modify_color] (
    [id] int IDENTITY(1,1) NOT NULL,
    [cid] int  NOT NULL,
    [state] int  NULL,
    [field_name] nvarchar(100)  NULL
);
GO

-- Creating table 'cases'
CREATE TABLE [dbo].[cases] (
    [id] int IDENTITY(1,1) NOT NULL,
    [cid] nvarchar(50)  NOT NULL,
    [current_state] int  NULL,
    [is_reported] int  NULL,
    [is_submit] int  NULL,
    [is_investigate] int  NULL,
    [is_data_holonomic] int  NULL,
    [data_remark] nvarchar(50)  NULL,
    [is_informed] int  NULL,
    [is_diffcult] int  NULL,
    [diffcult_reason] nvarchar(100)  NULL,
    [report_type] nvarchar(50)  NULL,
    [report_time] datetime  NULL,
    [report_phone] nvarchar(50)  NULL,
    [application_id] nvarchar(50)  NULL,
    [policy_id] nvarchar(50)  NULL,
    [policy_type] nvarchar(50)  NULL,
    [policy_holder] nvarchar(50)  NULL,
    [insurant_name] nvarchar(50)  NULL,
    [insurant_sex] nvarchar(50)  NULL,
    [insurant_habitation] nvarchar(100)  NULL,
    [insurant_idcard] nvarchar(50)  NULL,
    [insurant_age] int  NULL,
    [insurant_phone] nvarchar(50)  NULL,
    [accident_time] datetime  NULL,
    [accident_reason] nvarchar(500)  NULL,
    [accident_address] nvarchar(100)  NULL,
    [accident_details] nvarchar(50)  NULL,
    [hospital_name] nvarchar(50)  NULL,
    [hospital_type] nvarchar(50)  NULL,
    [hospital_days] int  NULL,
    [hospital_is_two_public] int  NULL,
    [transfer_bank] nvarchar(50)  NULL,
    [transfer_name] nvarchar(50)  NULL,
    [transfer_account] nvarchar(50)  NULL,
    [compensation_type] nvarchar(50)  NULL,
    [compensation_amount] float  NULL,
    [admissibility_type] nvarchar(50)  NULL,
    [subtract_type] nvarchar(50)  NULL,
    [subtract_amount] float  NULL,
    [invoice_amount] float  NULL,
    [deductible_amount] float  NULL,
    [adjustment_remark] nvarchar(500)  NULL,
    [is_need_communication] int  NULL,
    [communication_content] nvarchar(100)  NULL,
    [communication_result] int  NULL,
    [check_result] nvarchar(50)  NULL,
    [check_opinion] nvarchar(50)  NULL,
    [check_subtract_type] nvarchar(50)  NULL,
    [check_subtract_amount] float  NULL,
    [check_subtract_content] nvarchar(100)  NULL,
    [rejected_type] nvarchar(50)  NULL,
    [rejected_nature] nvarchar(50)  NULL,
    [rejected_amount] float  NULL,
    [rejected_reason] nvarchar(100)  NULL,
    [approval_result] nvarchar(50)  NULL,
    [report_user] nvarchar(50)  NULL,
    [report_submit_time] datetime  NULL,
    [record_user] nvarchar(50)  NULL,
    [record_submit_time] datetime  NULL,
    [adjust_user] nvarchar(50)  NULL,
    [adjust_submit_time] datetime  NULL,
    [check_user] nvarchar(50)  NULL,
    [check_submit_time] datetime  NULL,
    [approval_user] nvarchar(50)  NULL,
    [approval_submit_time] datetime  NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [fid] in table 'field_range'
ALTER TABLE [dbo].[field_range]
ADD CONSTRAINT [PK_field_range]
    PRIMARY KEY CLUSTERED ([fid] ASC);
GO

-- Creating primary key on [id] in table 'investigation'
ALTER TABLE [dbo].[investigation]
ADD CONSTRAINT [PK_investigation]
    PRIMARY KEY CLUSTERED ([id] ASC);
GO

-- Creating primary key on [uid] in table 'lgn'
ALTER TABLE [dbo].[lgn]
ADD CONSTRAINT [PK_lgn]
    PRIMARY KEY CLUSTERED ([uid] ASC);
GO

-- Creating primary key on [id], [cid] in table 'modify_color'
ALTER TABLE [dbo].[modify_color]
ADD CONSTRAINT [PK_modify_color]
    PRIMARY KEY CLUSTERED ([id], [cid] ASC);
GO

-- Creating primary key on [id] in table 'cases'
ALTER TABLE [dbo].[cases]
ADD CONSTRAINT [PK_cases]
    PRIMARY KEY CLUSTERED ([id] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------