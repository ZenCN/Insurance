angular.module('sbAdminApp')
    .directive('ngDatepicker',  function() {
        return {
            restrict: 'A',
            link: function($scope, $element) {
                $(function() {
                    $element.datetimepicker({
                        language: 'zh-CN',
                        autoclose: true,
                        todayHighlight: true,
                        format: 'yyyy-mm-dd',
                        endDate: tools.get_today(),
                        minView: 2
                    });
                });
            }
        };
});