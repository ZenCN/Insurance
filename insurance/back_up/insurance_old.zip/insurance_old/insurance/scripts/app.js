'use strict';
/**
 * @ngdoc overview
 * @name sbAdminApp
 * @description
 * # sbAdminApp
 *
 * Main module of the application.
 */
angular
    .module('sbAdminApp', [
        'oc.lazyLoad',
        'ui.router',
        'ui.bootstrap',
        'angular-loading-bar'
    ])
    .config([
        '$stateProvider', '$urlRouterProvider', '$ocLazyLoadProvider',
        function($stateProvider, $urlRouterProvider, $ocLazyLoadProvider) {

            $ocLazyLoadProvider.config({
                debug: false,
                events: true
            });

            $urlRouterProvider.when('', '/login');
            $urlRouterProvider.otherwise('/policy/search');

            $stateProvider
                .state('policy', {
                    url: '/policy',
                    controller: 'main_ctrl',
                    templateUrl: 'views/admin/main.html',
                    resolve: {
                        loadMyDirectives: function($ocLazyLoad) {
                            return $ocLazyLoad.load(
                            {
                                name: 'sbAdminApp',
                                files: [
                                    'scripts/directives/header/header.js',
                                    'scripts/directives/header/header-notification/header-notification.js',
                                    'scripts/directives/sidebar/sidebar.js',
                                    'scripts/directives/sidebar/sidebar-search/sidebar-search.js',
                                    'scripts/directives/datepicker/datepicker.js',
                                    'scripts/model.js',
                                    'scripts/controllers/main.js'
                                ]
                            });
                        }
                    }
                })
                .state('policy.search', {
                    url: '/search',
                    controller: 'search_ctrl',
                    templateUrl: function() {
                        if ($.cookie('authority_level') <= 3) {
                            return 'views/admin/search/normal.html';
                        } else {
                            return 'views/admin/search/unnormal.html';
                        }
                    },
                    resolve: {
                        loadMyFiles: function($ocLazyLoad) {
                            return $ocLazyLoad.load({
                                name: 'sbAdminApp',
                                files: [
                                    'scripts/controllers/search.js'
                                ]
                            });
                        }
                    },
                    onEnter: function($rootScope) {
                        $rootScope.state = 'search';
                    }
                })
                .state('policy.report', {
                    templateUrl: 'views/admin/policy/report/wrap.html',
                    url: '/report',
                    controller: 'report_ctrl',
                    onEnter: function($rootScope) {
                        $rootScope.state = 'report';
                    },
                    resolve: {
                        loadMyControllers: function($ocLazyLoad) {
                            return $ocLazyLoad.load({
                                name: 'sbAdminApp',
                                files: [
                                    'scripts/controllers/report.js'
                                ]
                            });
                        }
                    }
                })
                .state('policy.record', {
                    templateUrl: 'views/admin/policy/record/wrap.html',
                    url: '/record',
                    controller: 'record_ctrl',
                    onEnter: function($rootScope) {
                        $rootScope.state = 'record';
                    },
                    resolve: {
                        loadMyControllers: function($ocLazyLoad) {
                            return $ocLazyLoad.load({
                                name: 'sbAdminApp',
                                files: [
                                    'scripts/controllers/record.js'
                                ]
                            });
                        }
                    }
                })
                .state('policy.adjust', {
                    templateUrl: 'views/admin/policy/adjust/wrap.html',
                    url: '/adjust',
                    controller: 'adjust_ctrl',
                    onEnter: function($rootScope) {
                        $rootScope.state = 'adjust';
                    },
                    resolve: {
                        loadMyControllers: function($ocLazyLoad) {
                            return $ocLazyLoad.load({
                                name: 'sbAdminApp',
                                files: [
                                    'scripts/controllers/adjust.js'
                                ]
                            });
                        }
                    }
                })
                .state('policy.check', {
                    templateUrl: 'views/admin/policy/check/wrap.html',
                    url: '/check',
                    controller: 'check_ctrl',
                    onEnter: function($rootScope) {
                        $rootScope.state = 'check';
                    },
                    resolve: {
                        loadMyControllers: function($ocLazyLoad) {
                            return $ocLazyLoad.load({
                                name: 'sbAdminApp',
                                files: [
                                    'scripts/controllers/check.js'
                                ]
                            });
                        }
                    }
                })
                .state('policy.approval', {
                    templateUrl: 'views/admin/policy/approval/wrap.html',
                    url: '/approval',
                    controller: 'approval_ctrl',
                    onEnter: function($rootScope) {
                        $rootScope.state = 'approval';
                    },
                    resolve: {
                        loadMyControllers: function($ocLazyLoad) {
                            return $ocLazyLoad.load({
                                name: 'sbAdminApp',
                                files: [
                                    'scripts/controllers/approval.js'
                                ]
                            });
                        }
                    }
                })
                .state('policy.general_query', {
                    templateUrl: 'views/admin/query/general_query.html',
                    url: '/general_query',
                    controller: 'general_query_ctrl',
                    onEnter: function($rootScope) {
                        $rootScope.state = 'general_query';
                    },
                    resolve: {
                        loadMyControllers: function($ocLazyLoad) {
                            return $ocLazyLoad.load({
                                name: 'sbAdminApp',
                                files: [
                                    'scripts/controllers/general_query.js'
                                ]
                            });
                        }
                    }
                })
                .state('policy.details_query', {
                    templateUrl: 'views/admin/query/details_query.html',
                    url: '/details_query',
                    controller: 'details_query_ctrl',
                    onEnter: function ($rootScope) {
                        $rootScope.state = 'details_query';
                    },
                    resolve: {
                        loadMyControllers: function ($ocLazyLoad) {
                            return $ocLazyLoad.load({
                                name: 'sbAdminApp',
                                files: [
                                    'scripts/controllers/details_query.js'
                                ]
                            });
                        }
                    }
                })
                .state('policy.statistics_query', {
                    templateUrl: 'views/admin/query/statistics_query.html',
                    url: '/statistics_query',
                    controller: 'statistics_query_ctrl',
                    onEnter: function ($rootScope) {
                        $rootScope.state = 'statistics_query';
                    },
                    resolve: {
                        loadMyFiles: function ($ocLazyLoad) {
                            return $ocLazyLoad.load({
                                name: 'sbAdminApp',
                                files: [
                                    'scripts/controllers/statistics_query.js',
                                    'scripts/directives/statistics_query/directive.js',
                                    'js/libs/hcharts/highcharts.js',
                                    'js/libs/hcharts/exporting.js',
                                    'js/libs/hcharts/highcharts-3d.js'
                                ]
                            });
                        }
                    }
                })
                .state('policy.user_manager', {
                    templateUrl: 'views/admin/user_manager.html',
                    url: '/user_manager',
                    controller: 'user_manager_ctrl',
                    onEnter: function($rootScope) {
                        $rootScope.state = 'user_manager';
                    },
                    resolve: {
                        loadMyControllers: function($ocLazyLoad) {
                            return $ocLazyLoad.load({
                                name: 'sbAdminApp',
                                files: [
                                    'scripts/controllers/user_manager.js'
                                ]
                            });
                        }
                    }
                })
                .state('policy.data_config', {
                    templateUrl: 'views/admin/data_config.html',
                    url: '/data_config',
                    controller: 'data_config_ctrl',
                    onEnter: function($rootScope) {
                        $rootScope.state = 'data_config';
                    },
                    resolve: {
                        loadMyControllers: function($ocLazyLoad) {
                            return $ocLazyLoad.load({
                                name: 'sbAdminApp',
                                files: [
                                    'scripts/controllers/data_config.js'
                                ]
                            });
                        }
                    }
                })
                .state('login', {
                    templateUrl: 'views/login.html',
                    url: '/login',
                    resolve: {
                        loadMyDirectives: function($ocLazyLoad) {
                            return $ocLazyLoad.load(
                            {
                                name: 'sbAdminApp',
                                files: [
                                    'scripts/directives/login/directive.js'
                                ]
                            });
                        }
                    }
                });
        }
    ]);

    
